---
title: Indonesian Sundanese dictionary
heroImage: /src/assets/kamus-indonesia-sunda.png
heroAlt: Kamus bahasa Indonesia-Sunda menggunakan Algoritma BST
techstack:
  - Python
  - Flask
  - Javascript
  - Bootstrap5
  - Binary-search-tree-algorithm
github: https://github.com/0xtbug/kamus-indonesia-sunda
---

# Indonesian Sundanese dictionary
Aplikasi kamus bahasa Indonesia-Sunda menggunakan Python dan Flask dengan algoritma Binary Search Tree (BST) untuk mengelola kata.