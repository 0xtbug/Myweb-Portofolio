---
title: Study Tracker
heroImage: /src/assets/studytracker.png
heroAlt: Aplikasi untuk monitor jadwal
techstack:
  - Javascript
  - Bootstrap5
github: https://github.com/0xtbug/study-tracker
demo: https://study-tracker-vert.vercel.app/
---

# Study Tracker
Aplikasi untuk memonitor jadwal kuliah mahasiswa Fakultas Ilmu Komputer Universitas Singaperbangsa Karawang.