---
title: Gubook
heroImage: /src/assets/gubook.png
heroAlt: Perpustakaan Digital
techstack:
  - PHP
  - Mysql
  - Bootstrap5
  - Javascript
  - Datatables
github: https://github.com/0xtbug/gbook
demo: https://gubook.xyz
---
# Gubook
GUBOOK adalah perpustakaan digital untuk mahasiswa yang menyediakan akses legal ke ebook, artikel ilmiah, dan jurnal, serta platform publikasi untuk karya tulis mahasiswa.