---
title: Robogpt
heroImage: /src/assets/robogpt.png
heroAlt: Bot whatsapp yang menggunakan gpt 3
techstack:
  - Javascript
  - Nodejs
github: https://github.com/0xtbug/RoboGPT
---
# Robogpt
Bot whatsapp menggunakan gpt 3